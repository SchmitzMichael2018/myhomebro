import{a as c}from"./index-BRzt-bzr.js";async function s(t={}){return(await c.get("/projects/subaccounts/",{params:t})).data}async function o(t={}){return await s(t)}export{o as l};
