function o(r){return String(r||"").trim().toLowerCase()==="commercial"?"commercial":"residential"}export{o as n};
